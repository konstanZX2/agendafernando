public class ExcepcionPropia extends Exception {

    public ExcepcionPropia(){
        super("Este fichero no existe");
    }




}
